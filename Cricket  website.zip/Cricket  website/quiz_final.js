// set the quiz duration in seconds
    let quizDuration = 60;
    let time = 0;

// Get the timer element
    let timerElement = document.getElementById("timer");

// Start the quiz timer
    let quizTimer = setInterval(function() {
        // update the timer value
        timerElement.innerHTML = "Time: " + quizDuration + " s";
        time = 60 - quizDuration;

        // check if the quiz timer has reached zero
        if (quizDuration <= 0) {
            // Clear the interval and display a message
            clearInterval(quizTimer);
            timerElement.innerHTML = "Time's up!";
        }
        // Decrement of quiz duration
        quizDuration--;
    },1000);

    // This function is for refresh the webpage
    function refreshPage() {
        location.reload();
    }

    // Array of question objects
    let questions = [
        {
                    question: "What is the name of the annual test match between Australia and England?",
                    answers: ["a) ICC World Cup", "b) Coba America", "c) Ashes", "d) Don"],
                    correctAnswer: 2
                },
                {
                    question: "Who won the first ever Cricket World Cup in 1975?",
                    answers: ["a) Australia", "b) West Indies", "c) England", "d) India"],
                    correctAnswer: 1
                },
                {
                    
                    question: "Which fast bowler has taken the most test wickets up to now?",
                    answers: ["a) Stuart Broad", "b) Glenn McGrath ", "c) Dale Steyn", "d) James Anderson"],
                    correctAnswer: 3 
                },
                {
                    question: "Where will the 2023 Cricket World Cup be hosted?",
                    answers: ["a) New Zealand", "b) England", "c) West Indies", "d) India "],
                    correctAnswer: 3 
                },
                {
                    question: "Who is the only batsman to record 400 runs in an international Test match?",
                    answers: ["a) Sachin Tendulkar ", "b) Brian Lara", "c) Allan Border ", "d) Don Bradman "],
                    correctAnswer: 1 
                },
                {
                    question: " Who did England beat in the final of the 2019 Cricket World Cup?",
                    answers: ["a) South Africa", "b) Argentina", "c) Uruguay", "d) New Zealand"],
                    correctAnswer: 3 
                },
                {
                    question: "The first official international match of cricket was held in 1844 between...",
                    answers: ["a) India & Pakistan ", "b) USA & Canada ", "c) England & India", "d) England & Australia"],
                    correctAnswer: 1 
                },
                {
                    question: "How long is the wicket on a cricket pitch?",
                    answers: ["a) 18 yards", "b) 20 yards", "c) 22 yards", "d) 24 yards"],
                    correctAnswer: 2
                },
                {
                    question: "Which player has scored the most ducks in international cricket?",
                    answers: ["a) Muttiah Muralitharan", "b) Shoaib Akhtar", "c)  Wasim Akram", "d) Ricky Ponting "],
                    correctAnswer: 0
                },
                {
                    question: "Which of the Team has never Won the ICC one day International World Cup ?",
                    answers: ["a) England", "b) New Zealand", "c) West Indies", "d) India"],
                    correctAnswer: 1
                }
            ];

    let currentQuestion = 0;   // Representing index of "questions" array.
    let correctAnswers = 0;
    let wrongAnswers = 0;
    let grade = 0;

    // This function is helps to change the quiz questions
    function displayQuestion() {
        let questionElement = document.getElementById("question");
        let answersElement = document.getElementById("answers");
        let statusElement = document.getElementById("status");
        let nextButtonElement = document.getElementById("nextButton");

        // Clear previous question and answers.
        questionElement.textContent = "";
        answersElement.textContent = "";
        statusElement.textContent = "";

        // Display current question number and total number of questions.
        let questionCount = document.createElement("span");
        questionCount.textContent = "Question " + (currentQuestion + 1) + " of " + questions.length + " questions";
        questionCount.classList.add("B");
        statusElement.appendChild(questionCount);

        // Display current correct answer count.
        let correctCount = document.createElement("span");
        correctCount.textContent = "Correct Answers: " + correctAnswers;
        correctCount.classList.add("B");
        statusElement.appendChild(correctCount);

        // Display current question
        questionElement.textContent = questions[currentQuestion].question;

        // Display answer options
        for(let i = 0; i < questions[currentQuestion].answers.length; i++) {
            let answerElement = document.createElement("div");
            answerElement.className = "answer";
            answerElement.textContent = questions[currentQuestion].answers[i];

            // Attach click event listener to each answer
            answerElement.addEventListener("click", handleAnswerClick);

            answersElement.appendChild(answerElement);
        }
        // Hide "Next Question" button until an answer is selected.
        nextButtonElement.style.display = "block";
    }

    // This function is for handle the actions once the answer was clicked
    function handleAnswerClick(event) {
        let selectedAnswer = event.target;
        let answers = document.getElementsByClassName("answer");
        let correctAnswer = questions[currentQuestion].correctAnswer;

        // Check if selected answer is correct.
        if(selectedAnswer.textContent === questions[currentQuestion].answers[correctAnswer]) {
            selectedAnswer.classList.add("correct");    // Add "correct" class to the selected element
            correctAnswers++;  // Increment of "correctAnswers" count
            grade += 10;
        }
        else {
            selectedAnswer.classList.add("incorrect");  // Add "incorrect" class to the selected element
            wrongAnswers++;    // Increment of "wrongAnswers" count

            // Highlight the correct answer.
            answers[correctAnswer].classList.add("correct");
        }

        // Disable click event listeners on all answer.
        for(let i = 0; i < answers.length; i++) {
            answers[i].removeEventListener("click", handleAnswerClick);
        }

        // Activate "Next Question" button.
        let nextButtonElement = document.getElementById("nextButton");
        nextButtonElement.disabled = false;
    }

    // This function is helps to show the results once the was quiz completed
    function showResult() {
        let modal = document.getElementById("resultModal");
        modal.style.display = "block";
        let first = document.getElementById("1");
        first.textContent = "Question: " + questions.length;
        let second = document.getElementById("2");
        second.textContent = "Wrong Answers: " + wrongAnswers;
        let third = document.getElementById("3");
        third.textContent = "Score: " + correctAnswers;
        let fourth = document.getElementById("4");
        fourth.textContent = "Grade: " + grade + "%";
        let fifth = document.getElementById("5");
        fifth.textContent = "You took " + time + " s";
        let sixth = document.getElementById("6");
        if (time < 60) {
            if (grade >= 80 && grade <= 100) {
                sixth.textContent = "Excellent Mark. Keep up the good work";
                sixth.classList.add("greenword");
            }
            else if (grade >= 60 && grade < 80) {
                sixth.textContent = "Good. Keep it up";
                sixth.classList.add("greenword");
            }
            else if (grade >= 50 && grade < 60) {
                sixth.textContent = "Not Enough. You have to work";
                sixth.classList.add("redword");
            }
            else if (grade >= 40 && grade < 50) {
                sixth.textContent = "Poor. You have to work"
                sixth.classList.add("redword");
            }
            else if (grade >= 0 && grade < 40) {
                sixth.textContent = "Very Poor. You have to work with your GK";
                sixth.classList.add("redword");
            }
        }
        else if (time >= 60) {
            sixth.textContent = "Keep Time Management";
            sixth.classList.add("redword");
        }
    }

    function handleNextQuestionClick() {
        let answers = document.getElementsByClassName("answer");

        // Remove answer colour classes.
        for(let i = 0; i < answers.length; i++) {
            answers[i].classList.remove("correct", "incorrect");
        }

        // Increment current question index.
        currentQuestion++;

        // Display next question or end the quiz.
        if(currentQuestion < questions.length) {
            let nextButtonElement = document.getElementById("nextButton");
            nextButtonElement.disabled = true;
            displayQuestion();
        }
        else {
            showResult();
            // End of quiz.
            let questionElement = document.getElementById("question");
            let answersElement = document.getElementById("answers");
            let statusElement = document.getElementById("status");
            let nextButtonElement = document.getElementById("nextButton");
            let timerElement = document.getElementById("timer");

            questionElement.textContent = "Quiz Completed!";
            answersElement.textContent = "";
            statusElement.textContent = "";
            timerElement.textContent = "";


            // Display final correct answer output
            clearInterval(quizTimer);
            timerElement.textContent = "Thank You";

            nextButtonElement.style.display = "none";
        }
    }

// Start Quiz
    displayQuestion();

// Attach click event listener to "Next Question" button
    let nextButtonElement = document.getElementById("nextButton");
    nextButtonElement.addEventListener("click", handleNextQuestionClick);